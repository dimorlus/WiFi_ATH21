HT View - Portable Version 
========================== 
 
This is a portable version that doesn't require installation. 
Just run HT_view.exe to start the application. 
 
Files included: 
- HT_view.exe     : Main application 
- README.md       : Complete user guide 
- config.ini      : Configuration file 
- Qt6*.dll        : Required libraries 
- platforms/      : Platform plugins 
- imageformats/   : Image format support 
 
For complete documentation, open README.md in any text editor 
or web browser. 
 
Quick Start: 
1. Run HT_view.exe 
2. Click Open to load a CSV file 
3. Use D/W/M keys for Day/Week/Month views 
4. Mouse wheel to zoom, drag to pan 
 
System Requirements: Windows 10/11 64-bit 
Version: 1.0 
Total files: 28 
