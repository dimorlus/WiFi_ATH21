# AHT_Sensor
AHT10, AHT20, AHT21 Sensor Arduino Library

AHT10 Module

You can buy it on: https://www.aliexpress.com/item/33002710848.html

This is our store website: https://thinaryelectronic.aliexpress.com

![AHT10 Module](https://raw.githubusercontent.com/Thinary/AHT10/master/Image/AHT10.jpg)
