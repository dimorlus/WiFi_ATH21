# AHT21 Library
Library for AHT21 Sensor

Library develop for arduino code.

Tested on ESP32.
